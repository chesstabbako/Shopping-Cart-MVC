# Shopping-Cart-MVC
This one was created with PHP, MySQL, Js, JQuery, AJAX, CSS (not responsive yet) and obviously Html5. 100% Model-View-Controller by codeigniter
method. The logic fulfill:

a.- Each user has $100 after subscribing.
b.- The user can rate the items individually.
c.- The user can add items to the cart. If the purchase does not match, there is a section (order) where is possible to edit that. 
d.- Choosing a shipping option is demanded. 
e.- After clicking on 'complete' to pay, the system will display the shopping information (including the money available after the shop).

steps: 

1.- git clone (url) on your gitbash.
2.-This folder contains the database document (.sql) that must be imported using PhpMyAdmin.
