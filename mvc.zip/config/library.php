<?php

define("MAIN_CONTROLLER", "Cart");
define("MAIN_ACTION", "index");

?>