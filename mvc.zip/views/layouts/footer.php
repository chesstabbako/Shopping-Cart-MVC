      <footer>

            <!-- <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" class="svg">
                <path fill="darkgray" fill-opacity="0" d="M0,32L26.7,53.3C53.3,75,107,117,160,128C213.3,139,267,117,320,128C373.3,139,427,181,480,176C533.3,171,587,117,640,90.7C693.3,64,747,64,800,69.3C853.3,75,907,85,960,101.3C1013.3,117,1067,139,1120,160C1173.3,181,1227,203,1280,181.3C1333.3,160,1387,96,1413,64L1440,32L1440,0L1413.3,0C1386.7,0,1333,0,1280,0C1226.7,0,1173,0,1120,0C1066.7,0,1013,0,960,0C906.7,0,853,0,800,0C746.7,0,693,0,640,0C586.7,0,533,0,480,0C426.7,0,373,0,320,0C266.7,0,213,0,160,0C106.7,0,53,0,27,0L0,0Z"></path>
            </svg> -->

            <div class="footer-info">

                  <div class="social-media">

                        <a href="https://twitter.com/tabbaking" title="Go to Twitter">
                              <i class="icon-twitter"></i>
                              <!--icon-twitter is a class that is connected with
                              fontastic. So, while testing, if you don't see the icon, just
                              write a letter between the <i></i>, for example: <i>t</i>-->
                        </a>

                        <a href="https://instagram.com/chesstabbako/" title="Go to Instagram">
                              <i class="icon-instagram"></i>
                              <!--icon-instagram is a class that is connected with
                              fontastic. So, while testing, if you don't see the icon, just
                              write a letter between the <i></i>, for example: <i>i</i>-->

                        </a>

                        <p>All rights reserved!</p>

                  </div>

                  <div class="footer-img">

                        <img class='img' src="assets/images/tabaco111.png">

                  </div>

            </div>

            <!--footer-info finishes-->

      </footer>

      <!--footer finishes-->

      <script src="assets/js/ajax/jquery/jquery-3.5.1.min.js"></script>
      <script src="assets/js/ajax/btn_addcar.js"></script>
      <script src="assets/js/ajax/btn_delete.js"></script>
      <script src="assets/js/ajax/btn_change.js"></script>
      <script src="assets/js/ajax/btn_rating.js"></script>
      <script src="assets/js/ajax/btn_pay.js"></script>

      </body>

      </html>